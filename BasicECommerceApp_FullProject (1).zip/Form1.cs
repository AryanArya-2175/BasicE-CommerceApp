
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace BasicECommerceApp
{
    public partial class Form1 : Form
    {
        Dictionary<string, decimal> products = new Dictionary<string, decimal>();
        decimal total = 0;

        public Form1()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void LoadProducts()
        {
            products.Add("T-Shirt", 19.99m);
            products.Add("Jeans", 39.99m);
            products.Add("Sneakers", 59.99m);
            products.Add("Hat", 14.99m);

            foreach (var item in products)
            {
                lstProducts.Items.Add($"{item.Key} - ${item.Value}");
            }
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (lstProducts.SelectedItem != null)
            {
                string selectedItem = lstProducts.SelectedItem.ToString();
                lstCart.Items.Add(selectedItem);

                string productName = selectedItem.Split('-')[0].Trim();
                total += products[productName];

                lblTotal.Text = $"Total: ${total:F2}";
            }
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            if (lstCart.Items.Count == 0)
            {
                MessageBox.Show("Cart is empty!");
            }
            else
            {
                MessageBox.Show($"Purchase Complete!\nTotal Paid: ${total:F2}");
                lstCart.Items.Clear();
                total = 0;
                lblTotal.Text = "Total: $0.00";
            }
        }
    }
}
